import express from "express";
import ejs from "ejs";
import bodyParser  from "body-parser";

const app = express();
const port = 3000;
app.use(bodyParser.urlencoded({extended:true}))
app.use(express.static("public"))

app.get("/", (req, res) => {
    
    res.render("index.ejs")
});

app.post("/submit", (req, res) => {
    const blogPostContent = req.body["blog"]
    const day = new Date().getDate();
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    let month = months[new Date().getMonth()];
    const year = new Date().getFullYear()
    let currentDate = month + "/" + day + "/" + year;
     
    res.render("index.ejs", {
        blogContent: blogPostContent,
        currentDateNow:currentDate
    }) 
   
});
app.get("/edit/:id", (req, res) => {
    const postId = req.params.id;
    const existingContent = "Here is the existing Content";
    res.render("edit.ejs", {
        postId, existingContent,
    }); 
});

app.post("/update/:id", (req, res) => {
    const postId = req.params.id;
    const editedContent = req.body.editedBlog;
    res.redirect(`/post/${postId}`); 
});
app.get("/post/:id", (req, res) => {
    const postId = req.params.id;
    // Retrieve the content of the blog post with the given postId (e.g., from a database)
    // Replace the example content with actual data retrieval logic
    const blogContent = "Content of the blog post with ID " + postId;

    res.render("viewPost.ejs", {
        postId: postId,
        blogContent: blogContent,
    });
});
app.listen(port, () => {
    console.log(`currently listening from port ${port}`)
});