import express from 'express';
import ejs from "ejs"

const app = express();
const port = 3000;


app.get("/", (req, res) => {
    res.send("welcome")
});

app.listen(port, () => {
    console.log(`currently listening from port ${port}`)
});