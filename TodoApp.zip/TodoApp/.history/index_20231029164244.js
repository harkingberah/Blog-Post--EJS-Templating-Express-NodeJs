import express from "express";
import ejs from "ejs";

const app = express();
const port = 3000;

app.use(express.static("public"))

app.get("/", (req, res) => {
    res.render("index.ejs")
});
const 
app.post("/submit", (req, res) => {
    const blogPostContent=req.body["blog"]
    res.render("index.ejs", {
       blogContent:blogPostContent
   }) 
});

app.listen(port, () => {
    console.log(`currently listening from port ${port}`)
});