import express from "express";
import ejs from "ejs";
import bodyParser  from "body-parser";

const app = express();
const port = 3000;
app.use(bodyParser.urlencoded({extended:true}))
app.use(express.static("public"))

app.get("/", (req, res) => {
    res.render("index.ejs")
});
app.get("/about", (req, res) => {
    res.render("about.ejs")
});
app.get("/contact", (req, res) => {
    res.render("contact.ejs")
});
let blogPostStorage = [];
app.post("/submit", (req, res) => {
     
    const blogPostContent = req.body["blog"]
    blogPostStorage.push(blogPostContent)
    const day = new Date().getDate();
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const month = months[new Date().getMonth()];
    const year = new Date().getFullYear()
    const hour = new Date().getHours();
    const minutes = new Date().getMinutes();
    const seconds = new Date().getSeconds();
    const currentDate = month + "/" + day + "/" + year;
    const currentTime=hour + ":" +  + "/" + year;
   
    res.render("index.ejs", {
        blogContent: blogPostStorage,
        currentDateNow:currentDate
    }) 
   
});

app.post("/clear-posts", (req, res) => {
    // Clear the blogPostStorage array by reinitializing it as an empty array.
    blogPostStorage = [];

    res.redirect("/");
});







app.listen(port, () => {
    console.log(`currently listening from port ${port}`)
});