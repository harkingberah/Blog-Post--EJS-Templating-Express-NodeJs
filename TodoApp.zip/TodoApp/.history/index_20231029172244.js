import express from "express";
import ejs from "ejs";
import bodyParser  from "body-parser";

const app = express();
const port = 3000;
app.use(bodyParser.urlencoded({extended:true}))
app.use(express.static("public"))

app.get("/", (req, res) => {
    const blogId = 1;
    res.render("index.ejs", {
        blogId:blogId,
    })
});

let lastBlogId = 0;

app.post("/submit", (req, res) => {
    const blogPostContent = req.body["blog"]
     lastBlogId++;
    const day = new Date().getDate();
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    let month = months[new Date().getMonth()];
    const year = new Date().getFullYear()
    let currentDate=month+"/"+day+"/"+year
    res.render("index.ejs", {
        blogContent: blogPostContent,
        currentDateNow:currentDate
    }) 
    res.redirect(`/post/${lastBlogId}`);
});
app.get("/edit/:id", (req, res) => {
    const postId = req.params.id;
    const existingContent = "Here is the existing Content";
    res.render("edit.ejs", {
        postId, existingContent,
    }); 
});

app.post("/update/:id", (req, res) => {
    const postId = req.params.id;
    const editedContent = req.body.editedBlog;
    res.redirect(`/post/${postId}`); 
});
app.listen(port, () => {
    console.log(`currently listening from port ${port}`)
});