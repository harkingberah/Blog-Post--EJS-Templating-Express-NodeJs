import express from "express";
import ejs from "ejs";
import bodyParser  from "body-parser";

const app = express();
const port = 3000;
app.use(bodyParser.urlencoded({extended:true}))
app.use(express.static("public"))

app.get("/", (req, res) => {
    res.render("index.ejs")
});


const day=new Date().getDay()
const month = new Date().getMonth()
const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const year=new Date().getFullYear()



app.post("/submit", (req, res) => {
    const blogPostContent=req.body["blog"]
    res.render("index.ejs", {
       blogContent:blogPostContent
   }) 
});

app.listen(port, () => {
    console.log(`currently listening from port ${port}`)
});