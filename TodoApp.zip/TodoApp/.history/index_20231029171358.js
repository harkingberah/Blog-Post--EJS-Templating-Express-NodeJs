import express from "express";
import ejs from "ejs";
import bodyParser  from "body-parser";

const app = express();
const port = 3000;
app.use(bodyParser.urlencoded({extended:true}))
app.use(express.static("public"))

app.get("/", (req, res) => {
    res.render("index.ejs")
});


app.post("/submit", (req, res) => {
    const blogPostContent = req.body["blog"]
    const day = new Date().getDate();
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    let month = months[new Date().getMonth()];
    const year = new Date().getFullYear()
    let currentDate=month+"/"+day+"/"+year
    res.render("index.ejs", {
        blogContent: blogPostContent,
        currentDateNow:currentDate
   }) 
});
app.get("/edit/:id", (req, res) => {
    const postId = req.params.id
    res.render("edit.ejs", {
        postId, blogPostContent
    }); 
});

app.post("/update/:id", (req, res) => {
    const postId = req.params.id;
    const editedContent = req.body.editedBlog;

    // Update the post content in your database or data structure
    // You will typically use a database query to update the content

    // After updating, you can redirect the user to view the edited post or the homepage
    res.redirect(`/post/${postId}`); // Replace "post" with your actual route for viewing a post
});
app.listen(port, () => {
    console.log(`currently listening from port ${port}`)
});