import express from "express";
import ejs from "ejs";
import bodyParser  from "body-parser";

const app = express();
const port = 3000;
app.use(bodyParser.urlencoded({extended:true}))
app.use(express.static("public"))

app.get("/", (req, res) => {
    res.render("index.ejs")
});


app.post("/submit", (req, res) => {
    const blogPostContent = req.body["blog"]
    const day = new Date().getDate();
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    let month = months[new Date().getMonth()];
    const year = new Date().getFullYear()
let currentDate=month+"/"+day+"/"+year
    res.render("index.ejs", {
       blogContent:blogPostContent
   }) 
});

app.listen(port, () => {
    console.log(`currently listening from port ${port}`)
});